package s4.s4_prueba2_eduardochinchilla;

import java.util.Scanner;

public class S4_Prueba2_EduardoChinchilla {

    static Scanner read = new Scanner(System.in);

    public static void main(String[] args) {

        int opcion = 0;

        while (opcion != 2) {
            System.out.println("Menu");
            System.out.println("1. Figura");
            System.out.println("2. Salir");

            opcion = read.nextInt();

            switch (opcion) {

                case 1: {
                    System.out.println("Ingrese el tam: ");
                    int tam = read.nextInt();

                    while (tam < 6) {
                        System.out.println("Ingrese un numero mayor a 6: ");
                        tam = read.nextInt();
                    }

                    for (int i = 0; i < tam; i++) {
                        for (int j = 0; j < tam - i  ; j++) {
                            System.out.print("_");
                           if (i == 0 || j > tam|| i ==tam || j >tam-i ){
                               System.out.print("_");
                           }
                        }
                        for (int k = 0; k <= i * 2 - 1; k++) {
                            System.out.print("*");

                        }

                        System.out.println(" ");
                    }
                    //cuadrado vacio
                    for (int x = 1; x <= tam; x++) {

                        for (int y = 1; y <= tam*3+2; y++) {

                            if (x == 1 || x == tam || y == 1 || y == tam*3+2||(y==tam)) {
                                System.out.print('*');

                            } else {

                                System.out.print(" ");
                                
                            }
                            if (x == 9 && y == 2) {
                                    System.out.print("\33[31mX");
                                }
                        }

                        System.out.println(" ");
                    }

                    break;
                }
                case 2: {
                    System.out.println("Ha salido");
                    break;
                }

                default:
                    System.out.println("Error, vuelva a ingresar: ");
            }//fin switch
        }//fin while
    }
}
